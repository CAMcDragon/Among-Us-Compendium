﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SheriffMod
{
    public static class CustomGameOptions
    {
        public static bool showSheriff=false;
        public static float SheriffKillCD=25.0f;

    }
}
